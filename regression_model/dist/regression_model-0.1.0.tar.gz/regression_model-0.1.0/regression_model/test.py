import os
import pathlib

ROOT = pathlib.Path(housing_price_model.__file__).resolve().parent
print(ROOT)

